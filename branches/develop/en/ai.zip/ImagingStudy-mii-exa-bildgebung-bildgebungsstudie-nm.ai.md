# MII Example Bildgebung Imaging Study NM - MII IG Kerndatensatz-Modul Bildgebung v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII Example Bildgebung Imaging Study NM**

## Example ImagingStudy: MII Example Bildgebung Imaging Study NM

-------

**English**

-------

Profile: [MII PR Bildgebung Bildgebungsstudie](StructureDefinition-mii-pr-bildgebung-bildgebungsstudie.md)

**MII EX Bildgebung Bildgebungsgrund**: Verdacht auf Karzinom

**status**: Available

**modality**: [DICOM: NM](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html#dicom-dcim-NM) (Nuclear Medicine)

**subject**: [Erika Beispielpatientin Female, DoB: 1970-01-01](Patient-mii-exa-bildgebung-radiologischer-patient.md)

**encounter**: [Encounter: status = finished; class = AMB (AMB)](Encounter-mii-exa-bildgebung-radiologischer-fall.md)

**basedOn**: [ServiceRequest Mammography (procedure)](ServiceRequest-mii-exa-bildgebung-anforderung-bildgebung.md)

**numberOfSeries**: 2

**numberOfInstances**: 390

**procedureReference**: [Procedure Screening mammography of bilateral breasts (procedure)](Procedure-mii-exa-bildgebung-bildgebungsprozedur.md)

**reasonReference**: [Condition ](Condition-mii-exa-bildgebung-radiologische-diagnose.md)

**description**: whole body aquisition

> **series**
> **MII EX Bildgebung Modalität PT/NM**
* radiopharmaceutical: Fluorodeoxyglucose (18-F) (substance)
* radionuclide: Fluorine-18 (substance)
* tracerExposureTime: 10000 Seconds
* units: BQML
* radionuclideTotalDose: 196 Megabecquerel
* radionuclideHalfLife: 6586.2 Seconds

**uid**: series-example-uid**number**: 1**modality**: [DICOM: NM](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html#dicom-dcim-NM) (Nuclear Medicine)**description**: NM WB**numberOfInstances**: 195**bodySite**: [SNOMED CT: 51185008](http://snomed.info/id/51185008) (Thoracic structure (body structure)) (version = http://snomed.info/sct/900000000000207008/version/20260701 )**laterality**: [SNOMED CT: 66459002](http://snomed.info/id/66459002) (Unilateral) (version = http://snomed.info/sct/900000000000207008/version/20260701 )**started**: 2024-07-19 12:03:30+0200

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Device: manufacturer = Siemens](Device-mii-exa-bildgebung-geraet.md) |

### Instances

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **Extension** | **Uid** | **SopClass** | **Number** |
| * |  | instance-example-uid | unknown: urn:oid:1.2.840.10008.5.1.4.1.1.128 (urn:oid:1.2.840.10008.5.1.4.1.1.128) | 31 |




## Resource Content

```json
{
  "resourceType" : "ImagingStudy",
  "id" : "mii-exa-bildgebung-bildgebungsstudie-nm",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/StructureDefinition/mii-pr-bildgebung-bildgebungsstudie"]
  },
  "extension" : [{
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/StructureDefinition/mii-ex-bildgebung-bildgebungsgrund",
    "valueString" : "Verdacht auf Karzinom"
  }],
  "status" : "available",
  "modality" : [{
    "system" : "http://dicom.nema.org/resources/ontology/DCM",
    "code" : "NM",
    "display" : "Nuclear Medicine"
  }],
  "subject" : {
    "reference" : "Patient/mii-exa-bildgebung-radiologischer-patient",
    "identifier" : {
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
          "code" : "MR",
          "display" : "Medical record number"
        }]
      },
      "system" : "https://system-url",
      "value" : "study-uid"
    }
  },
  "encounter" : {
    "reference" : "Encounter/mii-exa-bildgebung-radiologischer-fall"
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/mii-exa-bildgebung-anforderung-bildgebung"
  }],
  "numberOfSeries" : 2,
  "numberOfInstances" : 390,
  "procedureReference" : {
    "reference" : "Procedure/mii-exa-bildgebung-bildgebungsprozedur"
  },
  "reasonReference" : [{
    "reference" : "Condition/mii-exa-bildgebung-radiologische-diagnose"
  }],
  "description" : "whole body aquisition",
  "series" : [{
    "extension" : [{
      "extension" : [{
        "url" : "radiopharmaceutical",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
            "code" : "35321007",
            "display" : "Fluorodeoxyglucose (18-F) (substance)"
          }]
        }
      },
      {
        "url" : "radionuclide",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
            "code" : "77004003",
            "display" : "Fluorine-18 (substance)"
          }]
        }
      },
      {
        "url" : "tracerExposureTime",
        "valueQuantity" : {
          "value" : 10000,
          "unit" : "Seconds"
        }
      },
      {
        "url" : "units",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://unitsofmeasure.org",
            "code" : "BQML"
          }]
        }
      },
      {
        "url" : "radionuclideTotalDose",
        "valueQuantity" : {
          "value" : 196,
          "unit" : "Megabecquerel"
        }
      },
      {
        "url" : "radionuclideHalfLife",
        "valueQuantity" : {
          "value" : 6586.2,
          "unit" : "Seconds"
        }
      }],
      "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/StructureDefinition/mii-ex-bildgebung-modalitaet-nm"
    }],
    "uid" : "series-example-uid",
    "number" : 1,
    "modality" : {
      "system" : "http://dicom.nema.org/resources/ontology/DCM",
      "code" : "NM",
      "display" : "Nuclear Medicine"
    },
    "description" : "NM WB",
    "numberOfInstances" : 195,
    "bodySite" : {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
      "code" : "51185008",
      "display" : "Thoracic structure (body structure)"
    },
    "laterality" : {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
      "code" : "66459002",
      "display" : "Unilateral"
    },
    "started" : "2024-07-19T12:03:30+02:00",
    "performer" : [{
      "actor" : {
        "reference" : "Device/mii-exa-bildgebung-geraet"
      }
    }],
    "instance" : [{
      "extension" : [{
        "extension" : [{
          "url" : "pixelSpacingX",
          "valueQuantity" : {
            "value" : 2.89,
            "unit" : "millimeter"
          }
        },
        {
          "url" : "pixelSpacingY",
          "valueQuantity" : {
            "value" : 2.89,
            "unit" : "millimeter"
          }
        },
        {
          "url" : "sliceThickness",
          "valueQuantity" : {
            "value" : 4,
            "unit" : "millimeter"
          }
        },
        {
          "url" : "imageType",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/CodeSystem/mii-cs-bildgebung-instance-image-type",
              "code" : "ORIGINAL"
            },
            {
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/CodeSystem/mii-cs-bildgebung-instance-image-type",
              "code" : "PRIMARY"
            },
            {
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/CodeSystem/mii-cs-bildgebung-instance-image-type",
              "code" : "DYNAMIC"
            },
            {
              "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/CodeSystem/mii-cs-bildgebung-instance-image-type",
              "code" : "EMISSION"
            }]
          }
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-bildgebung/StructureDefinition/mii-ex-bildgebung-instanz-details"
      }],
      "uid" : "instance-example-uid",
      "sopClass" : {
        "system" : "urn:ietf:rfc:3986",
        "code" : "urn:oid:1.2.840.10008.5.1.4.1.1.128"
      },
      "number" : 31
    }]
  }]
}

```
