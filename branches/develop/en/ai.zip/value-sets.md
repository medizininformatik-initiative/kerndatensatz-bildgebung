# Value Sets - MII IG Kerndatensatz-Modul Bildgebung v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* **Value Sets**

## Value Sets

This page describes the ValueSets of the **Bildgebung** module. The complete, automatically generated list of all ValueSets can be found in the [artifact overview](artifacts.md).

### Value sets defined by DICOM

The DICOM standard defines its own value sets for certain tags, which are also to be used in these profiles. These are:

* Modality: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_29.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_29.html)
* Laterality: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_244.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_244.html)
* SOP class: [https://dicom.nema.org/medical/dicom/current/output/chtml/part04/sect_B.5.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part04/sect_B.5.html)
* Radiopharmaceutical PT: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_4021.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_4021.html)
* Radionuclide PT: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_4020.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_4020.html)
* Radiopharmaceutical NM: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_25.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_25.html)
* Radionuclide NM: [https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_18.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_18.html)
* Scaling units: [http://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_84.html](http://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_84.html)

For tags with enumerated values for which the DICOM package defines no codes, the module created its own code systems with corresponding ValueSets — see the [code systems page](code-systems.md).

