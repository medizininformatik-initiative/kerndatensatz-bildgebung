Diese BodyStructure-Ressource wird verwendet, um die Körperstruktur, die in einer Observation-Ressource befundet wird, codiert abzubilden. Dazu wird hier unterteilt in die Morphologie, die Lokalisation und die Lage im Körper. Das hinterlegte CodeSystem von locationQualifier in R4 ist allerdings noch nicht ausreichend granular, um hier eine exakte Angabe darzustellen. 

---

Die Zuordnung der Datensatz-Elemente zu diesem Profil ist im [Logischen Modell Bildgebung](StructureDefinition-mii-lm-bildgebung.html) dokumentiert.

---

**Beispiele**

Beispiel einer BodyStructure-Ressource mit detaillierten Angaben zur untersuchten Körperregion:

[BodyStructure-mii-exa-bildgebung-koerperstruktur](BodyStructure-mii-exa-bildgebung-koerperstruktur.html)
